﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace cursovaya
{
    /// <summary>
    /// Логика взаимодействия для main_page.xaml
    /// </summary>
    public partial class main_page : Page
    {
        string game_mode = "score";
        string language = "ru";
        string[] file_text = File.ReadAllLines(@"player_info.txt");
        public main_page()
        {
            InitializeComponent();
            if (file_text[0] == "ru") lang.SelectedIndex = 0;
            else lang.SelectedIndex = 1;
        }

        private void mode_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            switch (mode.SelectedIndex)
            {
                case 0:
                    game_mode = "score";
                    break;
                case 1:
                    game_mode = "mistakes";
                    break;
            }
        }

        private void lang_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            switch (lang.SelectedIndex)
            {
                case 0:
                    language = "ru";
                    points_mode.Text = "На очки";
                    mists_mode.Text = "До 3 ошибок";
                    mode_text.Text = "Режим тренировки";
                    start_btn.Content = "Начать";
                    exit_btn.Content = "Выход";
                    lang_text.Text = "Язык";
                    break;
                case 1:
                    language = "en";
                    points_mode.Text = "For points";
                    mists_mode.Text = "Up to 3 errors";
                    mode_text.Text = "Training mode";
                    start_btn.Content = "Start";
                    exit_btn.Content = "Exit";
                    lang_text.Text = "Language";
                    break;
            }
            file_text[0] = language;
            File.WriteAllLines(@"player_info.txt", file_text);
        }

        private void exit_btn_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }

        private void start_btn_Click(object sender, RoutedEventArgs e)
        {
            if (game_mode == "score")
            {
                NavigationService.Navigate(new score_page());
            }
            else if (game_mode == "mistakes")
            {
                NavigationService.Navigate(new mistakes_page());
            }
        }
    }
}