﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Windows.Threading;
using static System.Net.Mime.MediaTypeNames;
using System.Text.RegularExpressions;

namespace cursovaya
{
    /// <summary>
    /// Логика взаимодействия для mistakes_page.xaml
    /// </summary>
    /// 
    public partial class mistakes_page : Page
    {
        int i = 0;
        int score = 0;
        int bestscore = 0;
        string[] file_text = File.ReadAllLines(@"player_info.txt");
        Random rnd = new Random();
        int int_mists = 0;
        string[] mist_texts;
        int lang_id;
        public mistakes_page()
        {
            InitializeComponent();
            bestscore = int.Parse(file_text[2]);
            if (file_text[0] == "ru")
            {
                lang_id = 0;
                mist_texts = File.ReadAllLines(@"ru_texts.txt", Encoding.Default);
                best_score_text.Text = "Лучший счёт: " + file_text[2];
                start_btn.Content = "Начать";
                leave_btn.Content = "Выйти";
                back_btn.Content = "Назад";
                score_text.Text = "Счёт: 0";
            }
            else
            {
                lang_id = 1;
                mist_texts = File.ReadAllLines(@"en_texts.txt", Encoding.Default);
                best_score_text.Text = "Best score: " + file_text[2];
                start_btn.Content = "Start";
                leave_btn.Content = "Exit";
                back_btn.Content = "Back";
                score_text.Text = "Score: 0";
            }
            text.Text = mist_texts[rnd.Next(0, 41)];
            InitializeComponent();
        }

        private void mist_score_back_btn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new main_page());
        }

        private void mist_score_start_btn_Click(object sender, RoutedEventArgs e)
        {
            i = 0;
            check_text.Text = "";
            int_mists = 0;
            score = 0;
            fir_mist.Foreground = Brushes.LightGray;
            sec_mist.Foreground = Brushes.LightGray;
            thi_mist.Foreground = Brushes.LightGray;
            string rnd_text = mist_texts[rnd.Next(0, 11)];
            text.Text = rnd_text;
            best_score_text.Visibility = Visibility.Hidden;
            start_btn.Visibility = Visibility.Hidden;
            back_btn.Visibility = Visibility.Hidden;
            leave_btn.Visibility = Visibility.Visible;
            mists.Visibility = Visibility.Visible;
            score_text.Visibility = Visibility.Visible;
            text.Visibility = Visibility.Visible;
            check_text.Visibility = Visibility.Visible;
            text_textbox.Focus();
        }

        private void mist_score_leave_btn_Click(object sender, RoutedEventArgs e)
        {
            check_text.Text = "";
            best_score_text.Visibility = Visibility.Visible;
            start_btn.Visibility = Visibility.Visible;
            back_btn.Visibility = Visibility.Visible;
            leave_btn.Visibility = Visibility.Hidden;
            mists.Visibility = Visibility.Hidden;
            score_text.Visibility = Visibility.Hidden;
            text.Visibility = Visibility.Hidden;
            check_text.Visibility = Visibility.Hidden;
            if (score > bestscore)
            {
                bestscore = score;
                file_text[2] = score.ToString();
                File.WriteAllLines(@"player_info.txt", file_text);
            }
            if (lang_id == 0) best_score_text.Text = "Лучший счёт: " + bestscore;
            else best_score_text.Text = "Best score: " + bestscore;
        }

        private void mist_score_textbox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            char[] letters = text.Text.ToCharArray();
            int len = letters.Length - 1;
            bool flag = false;
            if ((e.KeyboardDevice.Modifiers == ModifierKeys.Shift && e.Key == Key.OemQuestion) && (letters[i] == ',')) flag = true;
            else
            {
                if (e.Key == Key.Q)
                {
                    if ((letters[i] == 'Й') || (letters[i] == 'Q'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.W))
                {
                    if ((letters[i] == 'Ц') || (letters[i] == 'W'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.E))
                {
                    if ((letters[i] == 'У') || (letters[i] == 'E'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.R))
                {
                    if ((letters[i] == 'К') || (letters[i] == 'R'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.T))
                {
                    if ((letters[i] == 'Е') || (letters[i] == 'T'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.Y))
                {
                    if ((letters[i] == 'Н') || (letters[i] == 'Y'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.U))
                {
                    if ((letters[i] == 'Г') || (letters[i] == 'U'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.I))
                {
                    if ((letters[i] == 'Ш') || (letters[i] == 'I'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.O))
                {
                    if ((letters[i] == 'Щ') || (letters[i] == 'O'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.P))
                {
                    if ((letters[i] == 'З') || (letters[i] == 'P'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.OemMinus))
                {
                    if (letters[i] == '-')
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.KeyboardDevice.Modifiers == ModifierKeys.Shift && e.Key == Key.D1))
                {
                    if (letters[i] == '!')
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.OemOpenBrackets))
                {
                    if (letters[i] == 'Х')
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.OemCloseBrackets))
                {
                    if (letters[i] == 'Ъ')
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.OemQuotes))
                {
                    if ((letters[i] == 'Э') || (letters[i].ToString() == "'"))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.OemSemicolon))
                {
                    if (letters[i] == 'Ж')
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.OemQuestion))
                {
                    if ((letters[i] == '.') && (lang_id == 0))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.OemComma))
                {
                    if ((letters[i] == 'Б') || (letters[i] == ','))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.OemPeriod))
                {
                    if ((letters[i] == 'Ю') || (letters[i] == '.'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.A))
                {
                    if ((letters[i] == 'Ф') || (letters[i] == 'A'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.S))
                {
                    if ((letters[i] == 'Ы') || (letters[i] == 'S'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.D))
                {
                    if ((letters[i] == 'В') || (letters[i] == 'D'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.F))
                {
                    if ((letters[i] == 'А') || (letters[i] == 'F'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.G))
                {
                    if ((letters[i] == 'П') || (letters[i] == 'G'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.H))
                {
                    if ((letters[i] == 'Р') || (letters[i] == 'H'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.J))
                {
                    if ((letters[i] == 'О') || (letters[i] == 'J'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.K))
                {
                    if ((letters[i] == 'Л') || (letters[i] == 'K'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.L))
                {
                    if ((letters[i] == 'Д') || (letters[i] == 'L'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.Z))
                {
                    if ((letters[i] == 'Я') || (letters[i] == 'Z'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.X))
                {
                    if ((letters[i] == 'Ч') || (letters[i] == 'X'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.C))
                {
                    if ((letters[i] == 'С') || (letters[i] == 'C'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.V))
                {
                    if ((letters[i] == 'М') || (letters[i] == 'V'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.B))
                {
                    if ((letters[i] == 'И') || (letters[i] == 'B'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.N))
                {
                    if ((letters[i] == 'Т') || (letters[i] == 'N'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.M))
                {
                    if ((letters[i] == 'Ь') || (letters[i] == 'M'))
                        flag = true;
                    else
                        int_mists++;
                }
                else if ((e.Key == Key.Space))
                {
                    if (letters[i] == ' ')
                        flag = true;
                    else
                        int_mists++;
                }
            }
            switch (int_mists)
            {
                case 1:
                    fir_mist.Foreground = Brushes.Red;
                    break;
                case 2:
                    sec_mist.Foreground = Brushes.Red;
                    break;
                case 3:
                    thi_mist.Foreground = Brushes.Red;
                    break;
            }
            if (int_mists == 3)
            {
                if (score > bestscore)
                {
                    bestscore = score;
                    file_text[2] = score.ToString();
                    File.WriteAllLines(@"player_info.txt", file_text);
                }
                if (lang_id == 0) best_score_text.Text = "Лучший счёт: " + bestscore;
                else best_score_text.Text = "Best score: " + bestscore;
                best_score_text.Visibility = Visibility.Visible;
                start_btn.Visibility = Visibility.Visible;
                back_btn.Visibility = Visibility.Visible;
                leave_btn.Visibility = Visibility.Hidden;
                mists.Visibility = Visibility.Hidden;
                score_text.Visibility = Visibility.Hidden;
                text.Visibility = Visibility.Hidden;
                check_text.Visibility = Visibility.Hidden;
                int_mists = 0;
                score = 0;
                text_textbox.Focus();
                text_textbox.Text = "";
            }
            if (flag)
            {
                score++;
                check_text.Text += char.ToLower(letters[i]);
                if (i == len)
                {
                    check_text.Text = "";
                    text.Text = mist_texts[rnd.Next(0, 41)];
                    letters = text.Text.ToCharArray();
                    i = 0;
                }
                else
                {
                    if (Regex.IsMatch(letters[i + 1].ToString(), @"^[\p{L}]+$"))
                    {
                        letters[i + 1] = char.ToUpper(letters[i + 1]);
                    }
                    letters[i] = char.ToLower(letters[i]);
                    text.Text = new string(letters);
                    i++;
                    flag = false;
                }
            }
            if (lang_id == 0) score_text.Text = "Счёт: " + score.ToString();
            else score_text.Text = "Score: " + score.ToString();
        }
    }
}
