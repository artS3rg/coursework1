﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Windows.Threading;
using System.Text.RegularExpressions;

namespace cursovaya
{
    /// <summary>
    /// Логика взаимодействия для score_page.xaml
    /// </summary>
    public partial class score_page : Page
    {
        DispatcherTimer _timer;
        int _time;
        int isStarted = 0;
        int i = 0;
        int score = 0;
        int bestscore = 0;
        string[] file_text = File.ReadAllLines(@"player_info.txt");
        Random rnd = new Random();
        int lang_id;
        string[] mist_texts;

        public score_page()
        {
            InitializeComponent();
            bestscore = int.Parse(file_text[1]);
            if (file_text[0] == "ru")
            {
                lang_id = 0;
                mist_texts = File.ReadAllLines(@"ru_texts.txt", Encoding.Default);
                best_score_text.Text = "Лучший счёт: " + file_text[1];
                score_start_btn.Content = "Начать";
                score_leave_btn.Content = "Выйти";
                score_back_btn.Content = "Назад";
                score_text.Text = "Счёт: 0";
            }
            else
            {
                lang_id = 1;
                mist_texts = File.ReadAllLines(@"en_texts.txt", Encoding.Default);
                best_score_text.Text = "Best score: " + file_text[1];
                score_start_btn.Content = "Start";
                score_leave_btn.Content = "Exit";
                score_back_btn.Content = "Back";
                score_text.Text = "Score: 0";
            }
            InitializeComponent();
        }

        private void score_back_btn_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new main_page());
        }

        private void score_start_btn_Click(object sender, RoutedEventArgs e)
        {
            i = 0;
            string rnd_text = mist_texts[rnd.Next(0, 41)];
            text.Text = rnd_text;
            score_textbox.Focus();
            best_score_text.Visibility = Visibility.Hidden;
            score_start_btn.Visibility = Visibility.Hidden;
            score_back_btn.Visibility = Visibility.Hidden;
            score_leave_btn.Visibility = Visibility.Visible;
            text.Visibility = Visibility.Visible;
            tbTime.Visibility = Visibility.Visible;
            rect_time.Visibility = Visibility.Visible;
            score_text.Visibility = Visibility.Visible;
            check_text.Visibility = Visibility.Visible;
            tbTime.Text = "3:00";
            rect_time.Width = 1080;
            isStarted = 1;
            _time = 179;
            _timer = new DispatcherTimer(new TimeSpan(0, 0, 1), DispatcherPriority.Normal, delegate
            {
                
                if ((_time < 10) || ((_time < 70) && (_time > 59)) || ((_time < 130) && (_time > 119)))
                {
                    tbTime.Text = string.Format("{0}:0{1}", _time / 60, _time % 60);
                }
                else
                {
                    tbTime.Text = string.Format("{0}:{1}", _time / 60, _time % 60);
                }
                if ((_time == 0) || (isStarted == 0)) 
                {
                    _timer.Stop();
                    if (score > bestscore)
                    {
                        bestscore = score;
                        file_text[1] = score.ToString();
                        File.WriteAllLines(@"player_info.txt", file_text);
                    }
                    if (lang_id == 0) best_score_text.Text = "Лучший счёт: " + bestscore;
                    else best_score_text.Text = "Best score: " + bestscore;
                    check_text.Text = "";
                    best_score_text.Visibility = Visibility.Visible;
                    score_start_btn.Visibility = Visibility.Visible;
                    score_back_btn.Visibility = Visibility.Visible;
                    score_leave_btn.Visibility = Visibility.Hidden;
                    text.Visibility = Visibility.Hidden;
                    tbTime.Visibility = Visibility.Hidden;
                    rect_time.Visibility = Visibility.Hidden;
                    score_text.Visibility = Visibility.Hidden;
                    check_text.Visibility = Visibility.Hidden;
                    isStarted = 0;
                    _time = 0;
                    score = 0;
                }
                _time--;
                rect_time.Width -= 6;
            }, Application.Current.Dispatcher);
            _timer.Start();
        }

        private void score_leave_btn_Click(object sender, RoutedEventArgs e)
        {
            check_text.Text = "";
            best_score_text.Visibility = Visibility.Visible;
            score_start_btn.Visibility = Visibility.Visible;
            score_back_btn.Visibility = Visibility.Visible;
            score_leave_btn.Visibility = Visibility.Hidden;
            text.Visibility = Visibility.Hidden;
            tbTime.Visibility = Visibility.Hidden;
            rect_time.Visibility = Visibility.Hidden;
            score_text.Visibility = Visibility.Hidden;
            check_text.Visibility = Visibility.Hidden;
            isStarted = 0;
            _time = 0;
            score = 0;
            _timer.Stop();
        }

        private void score_textbox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            char[] letters = text.Text.ToCharArray();
            int len = letters.Length - 1;
            bool flag = false;
            if ((e.Key == Key.Q) && ((letters[i] == 'Й') || (letters[i] == 'Q')))
            {
                flag = true;
            }
            else if ((e.Key == Key.W) && ((letters[i] == 'Ц') || (letters[i] == 'W')))
            {
                flag = true;
            }
            else if ((e.Key == Key.E) && ((letters[i] == 'У') || (letters[i] == 'E')))
            {
                flag = true;
            }
            else if ((e.Key == Key.R) && ((letters[i] == 'К') || (letters[i] == 'R')))
            {
                flag = true;
            }
            else if ((e.Key == Key.T) && ((letters[i] == 'Е') || (letters[i] == 'T')))
            {
                flag = true;
            }
            else if ((e.Key == Key.Y) && ((letters[i] == 'Н') || (letters[i] == 'Y')))
            {
                flag = true;
            }
            else if ((e.Key == Key.U) && ((letters[i] == 'Г') || (letters[i] == 'U')))
            {
                flag = true;
            }
            else if ((e.Key == Key.I) && ((letters[i] == 'Ш') || (letters[i] == 'I')))
            {
                flag = true;
            }
            else if ((e.Key == Key.O) && ((letters[i] == 'Щ') || (letters[i] == 'O')))
            {
                flag = true;
            }
            else if ((e.Key == Key.P) && ((letters[i] == 'З') || (letters[i] == 'P')))
            {
                flag = true;
            }
            else if ((e.Key == Key.OemMinus) && (letters[i] == '-'))
            {
                flag = true;
            }
            else if ((e.KeyboardDevice.Modifiers == ModifierKeys.Shift && e.Key == Key.D1) && (letters[i] == '!'))
            {
                flag = true;
            }
            else if ((e.Key == Key.OemOpenBrackets) && (letters[i] == 'Х'))
            {
                flag = true;
            }
            else if ((e.Key == Key.OemCloseBrackets) && (letters[i] == 'Ъ'))
            {
                flag = true;
            }
            else if ((e.Key == Key.OemQuotes) && ((letters[i] == 'Э') || (letters[i].ToString() == "'")))
            {
                flag = true;
            }
            else if ((e.Key == Key.OemSemicolon) && (letters[i] == 'Ж'))
            {
                flag = true;
            }
            else if ((e.Key == Key.OemQuestion) && (letters[i] == '.') && (lang_id == 0))
            {
                flag = true;
            }
            else if ((e.KeyboardDevice.Modifiers == ModifierKeys.Shift && e.Key == Key.OemQuestion) && (letters[i] == ','))
            {
                flag = true;
            }
            else if ((e.Key == Key.OemComma) && ((letters[i] == 'Б') || (letters[i] == ',')))
            {
                flag = true;
            }
            else if ((e.Key == Key.OemPeriod) && ((letters[i] == 'Ю') || (letters[i] == '.')))
            {
                flag = true;
            }
            else if ((e.Key == Key.A) && ((letters[i] == 'Ф') || (letters[i] == 'A')))
            {
                flag = true;
            }
            else if ((e.Key == Key.S) && ((letters[i] == 'Ы') || (letters[i] == 'S')))
            {
                flag = true;
            }
            else if ((e.Key == Key.D) && ((letters[i] == 'В') || (letters[i] == 'D')))
            {
                flag = true;
            }
            else if ((e.Key == Key.F) && ((letters[i] == 'А') || (letters[i] == 'F')))
            {
                flag = true;
            }
            else if ((e.Key == Key.G) && ((letters[i] == 'П') || (letters[i] == 'G')))
            {
                flag = true;
            }
            else if ((e.Key == Key.H) && ((letters[i] == 'Р') || (letters[i] == 'H')))
            {
                flag = true;
            }
            else if ((e.Key == Key.J) && ((letters[i] == 'О') || (letters[i] == 'J')))
            {
                flag = true;
            }
            else if ((e.Key == Key.K) && ((letters[i] == 'Л') || (letters[i] == 'K')))
            {
                flag = true;
            }
            else if ((e.Key == Key.L) && ((letters[i] == 'Д') || (letters[i] == 'L')))
            {
                flag = true;
            }
            else if ((e.Key == Key.Z) && ((letters[i] == 'Я') || (letters[i] == 'Z')))
            {
                flag = true;
            }
            else if ((e.Key == Key.X) && ((letters[i] == 'Ч') || (letters[i] == 'X')))
            {
                flag = true;
            }
            else if ((e.Key == Key.C) && ((letters[i] == 'С') || (letters[i] == 'C')))
            {
                flag = true;
            }
            else if ((e.Key == Key.V) && ((letters[i] == 'М') || (letters[i] == 'V')))
            {
                flag = true;
            }
            else if ((e.Key == Key.B) && ((letters[i] == 'И') || (letters[i] == 'B')))
            {
                flag = true;
            }
            else if ((e.Key == Key.N) && ((letters[i] == 'Т') || (letters[i] == 'N')))
            {
                flag = true;
            }
            else if ((e.Key == Key.M) && ((letters[i] == 'Ь') || (letters[i] == 'M')))
            {
                flag = true;
            }
            else if ((e.Key == Key.Space) && (letters[i] == ' '))
            {
                flag = true;
            }
            if (flag)
            {
                check_text.Text += char.ToLower(letters[i]);
                score++;
                if (i == len)
                {
                    text.Text = mist_texts[rnd.Next(0, 41)];
                    letters = text.Text.ToCharArray();
                    check_text.Text = "";
                    i = 0;
                }
                else
                {
                    if (Regex.IsMatch(letters[i + 1].ToString(), @"^[\p{L}]+$"))
                    {
                        letters[i + 1] = char.ToUpper(letters[i + 1]);
                    }
                    letters[i] = char.ToLower(letters[i]);
                    text.Text = new string(letters);
                    i++;
                    flag = false;
                }
            }
            if (lang_id == 0)
            {
                score_text.Text = "Счёт: " + score.ToString();
            }
            else
            {
                score_text.Text = "Score: " + score.ToString();
            }
        }
    }
}